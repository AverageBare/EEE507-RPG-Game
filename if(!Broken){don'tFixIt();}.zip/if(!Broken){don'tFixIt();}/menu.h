/*
* @author Jordan McMullan <McMullan-J20@ulster.ac.uk>
* @license https://choosealicense.com/licenses/mit/
* @copyright if(!Broken){don'tFixIt();}
*/
#pragma once

#include <iostream>
#include <iomanip>
#include <string>
#include <windows.h>
#include "CCreator.h"
#include "TileMap.h"
#include "item.h"
#include <ctime>
using namespace std;

/**
 * Displays the main menu of the High Roll Chonicles game.
 * The player can select from a range of options here.
 */

class menu
{
private:

	int Difficulty;
	bool Start;
	bool Exit;

public:

	menu();

	/**
   * The below sleep fuction delays the output of a case input.
   */
	void sleep(unsigned long msecs);

	/**
   * These are prototypes of the main functions in my code.
   */
	void mainmenu();
	void input();

	/**
   * The below fuctions are how the private variable will be read by other classes.
   */
	bool getStart();
	bool getExit();
	int getDifficulty();

	//Map
	TileMap map;

	//cCreater
	CCreator players;

};