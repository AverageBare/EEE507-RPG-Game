/** Main 
* 
* @author Conan McKilkenny
* @author Jeremy Eastwood-Smith <eastwood_smith-j@ulster.ac.uk>
* @licence https://choosealicense.com/licenses/mit/
* @copywrite if(!Broken){don'tFixIt();}
*/

#include "CCreator.h"
#include "TileMap.h"
#include "menu.h"

int main(void)
{
	menu Game;

	Game.mainmenu();

	return 0;
}