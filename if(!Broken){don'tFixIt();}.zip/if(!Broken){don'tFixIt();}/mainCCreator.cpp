/** Test mains
* CCreator function testing
* 
* @author Jeremy Eastwood-Smith <eastwood_smith-j@ulster.ac.uk>
* @licence https://choosealicense.com/licenses/mit/
* @copywrite if(!Broken){don'tFixIt();}
*/
#include "CCreator.h"

/** Test Max
* 
*/
int main(void)
{
	int loop;
	CCreator test(1);

	test.AddEnemies(20);
	test.AddEnemies(3);

	std::cout << test.ArraySize() << " == ";
	std::cout << test.NumPlayers() << endl;

	for (loop = 0; loop < 20; loop++)
	{
		test.UpdateEnemies();

	}


	
	//test.EnemyArray();
}